from WSI_handling.wsi import wsi
